#!/bin/bash
PATH="/home/t0315000/SHREYA/06-02-25"
/usr/bin/touch $PATH/testfile

echo "Cron job sample file">$PATH/testfile
