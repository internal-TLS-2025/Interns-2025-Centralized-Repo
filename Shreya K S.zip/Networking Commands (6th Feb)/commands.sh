#!/bin/bash

echo "Directory name?"
read  dir
mkdir "$dir"
