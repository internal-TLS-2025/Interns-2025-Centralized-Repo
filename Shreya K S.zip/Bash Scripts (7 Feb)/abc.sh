echo "Hello World " >> /tmp/o1.txt






